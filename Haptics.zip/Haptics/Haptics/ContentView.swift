import SwiftUI

struct ContentView: View {
    
    // Vibration control states
    @State private var isVibrating = false
    @State private var vibrationFrequency: Double = 0.1
    @State private var vibrationStrength: Int = 1
    @State private var vibrationDuration: Double = 0.1
    @State private var isAlternatingPattern = false
    @State private var useRandomInterval = false
    @State private var randomIntervalLowerBound: Double = 0.05
    @State private var randomIntervalUpperBound: Double = 0.2
    @State private var selectedPattern: VibrationPattern = .continuous
    @State private var hapticTimer: Timer?

    var body: some View {
        VStack(spacing: 15) {
            // Start/Stop Button
            Button(action: toggleVibration) {
                Text(isVibrating ? "Stop Vibration" : "Start Vibration")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isVibrating ? Color.red : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            
            // Configuration Sliders and Toggles
            VStack(alignment: .leading, spacing: 15) {
                // Vibration Frequency Slider
                VStack {
                    Text("Vibration Frequency: \(vibrationFrequency, specifier: "%.2f")s")
                    Slider(value: $vibrationFrequency, in: 0.01...0.5, step: 0.01)
                }
                
                // Vibration Strength Slider
                VStack {
                    Text("Vibration Strength: \(vibrationStrength)")
                    Slider(value: Binding(
                        get: { Double(vibrationStrength) },
                        set: { vibrationStrength = Int($0) }
                    ), in: 1...5, step: 1)
                }
                
                // Vibration Duration Slider
                VStack {
                    Text("Vibration Duration: \(vibrationDuration, specifier: "%.2f")s")
                    Slider(value: $vibrationDuration, in: 0.05...0.5, step: 0.05)
                }
                
                // Random Interval Toggle
                Toggle("Randomize Interval Between Pulses", isOn: $useRandomInterval)
                
                if useRandomInterval {
                    VStack {
                        Text("Random Interval Range: \(randomIntervalLowerBound, specifier: "%.2f")s - \(randomIntervalUpperBound, specifier: "%.2f")s")
                        Slider(value: $randomIntervalLowerBound, in: 0.01...randomIntervalUpperBound - 0.01, step: 0.01)
                        Slider(value: $randomIntervalUpperBound, in: randomIntervalLowerBound + 0.01...0.5, step: 0.01)
                    }
                }
                
                // Alternating Pattern Toggle
                Toggle("Use Alternating Pattern", isOn: $isAlternatingPattern)
                
                // Pattern Selection Picker
                Picker("Select Vibration Pattern", selection: $selectedPattern) {
                    ForEach(VibrationPattern.allCases, id: \.self) { pattern in
                        Text(pattern.rawValue.capitalized).tag(pattern)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            .padding()
        }
        .frame(width: 350, height: 450) // Fixed window size
        .padding()
    }
    
    // Function to toggle vibration on or off
    private func toggleVibration() {
        isVibrating.toggle()
        
        if isVibrating {
            startVibration()
        } else {
            stopVibration()
        }
    }

    // Start continuous vibration (haptic feedback) based on user settings
    private func startVibration() {
        stopVibration() // Ensure no existing timer is running
        
        hapticTimer = Timer.scheduledTimer(withTimeInterval: nextInterval(), repeats: true) { _ in
            if selectedPattern == .alternating && isAlternatingPattern {
                triggerAlternatingPattern()
            } else if selectedPattern == .random {
                triggerRandomPattern()
            } else {
                triggerContinuousVibration()
            }
        }
    }

    // Stop the vibration
    private func stopVibration() {
        hapticTimer?.invalidate()
        hapticTimer = nil
    }
    
    // Trigger haptic feedback based on strength setting
    private func triggerHapticFeedback() {
        let feedbackManager = NSHapticFeedbackManager.defaultPerformer
        for _ in 0..<vibrationStrength {
            feedbackManager.perform(.generic, performanceTime: .now)
            usleep(useconds_t(vibrationDuration * 1_000_000))
        }
    }
    
    // Vibration patterns
    private func triggerContinuousVibration() {
        triggerHapticFeedback()
    }
    
    private func triggerAlternatingPattern() {
        triggerHapticFeedback()
        usleep(useconds_t(vibrationFrequency * 1_000_000))
    }
    
    private func triggerRandomPattern() {
        for _ in 0..<Int.random(in: 1...vibrationStrength) {
            triggerHapticFeedback()
            usleep(useconds_t(vibrationDuration * 1_000_000))
        }
    }
    
    // Generate next interval for randomizing intervals
    private func nextInterval() -> TimeInterval {
        return useRandomInterval ? Double.random(in: randomIntervalLowerBound...randomIntervalUpperBound) : vibrationFrequency
    }
}

// Enum to define vibration patterns
enum VibrationPattern: String, CaseIterable {
    case continuous
    case alternating
    case random
}

@main
struct HapticApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .fixedSize() // Locks window size to prevent resizing
        }
    }
}
